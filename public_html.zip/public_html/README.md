# ngochn-web

1. Code xong --> Save lại tất cả các files
2. Chạy các câu lệnh sau
git add
git commit -m "Update code"
git push